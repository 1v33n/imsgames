    </div>
</main>

<footer class="footer">
    <div class="footer-container">
        <span class="text-muted">&copy; imsgames 2022</span>
        <a href="https://bwdbern.ch/ims/ausbildung/dein-abschluss/" target="_blank"> <img src="/images/bwd_Logo.png" alt="bwd Logo" height=30px></a>
    </div>
</footer>

<script src="/js/nav.js"></script>
</html>
